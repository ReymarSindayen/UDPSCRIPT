<?php
    // Redirection to the login directory
    header('Location: /security/');
    exit();
?>