<?php
session_start();

// Define your username and password
$credentials = [
    '404' => '404',
    'user2' => 'user2',
    'user3' => 'password3',
];
$error = '';

// Check if form was submitted
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the submitted username and password
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the entered username and password match the correct ones
    if(array_key_exists($username, $credentials) && $credentials[$username] === $password) {
        // Credentials are correct
        $_SESSION['loggedin'] = true;  // Set session variable
        $_SESSION['expiry'] = time() + 4 * 60 * 60;
        header('Location: /dashboard');
        exit;
    } else {
        // Credentials are incorrect
        $error = 'Invalid username or password.';
    }
} elseif (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    if(time() > $_SESSION['expiry']) {
        // Session has expired, log the user out
        unset($_SESSION['loggedin']);
        unset($_SESSION['expiry']);
        header('Location: /security');
        exit;
    } else {
        // User is still logged in and session has not expired
        header('Location: /dashboard');
        exit;
    }
}
?>

<!-- Your HTML form code -->

<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="index.css">
  <title>Private Checker</title>
</head>
<body>
    <section>
        <div class="form-box">
            <div class="form-value">
                <form action="" method="post">
                    <h2>LOGIN</h2>
                    <div class="inputbox">
                        <ion-icon name="person-outline"></ion-icon>
                        <input type="text" name="username" required>
                        <label for="username">Username</label>
                    </div>
                    <div class="inputbox">
                        <ion-icon name="key-outline"></ion-icon>
                        <input type="password" name="password" required>
                        <label for="password">Password</label>
                    </div>
                    <div class="forget">
                        <label for=""><input type="checkbox">Remember Me  <a href="#">Forget Password</a></label>
                    </div>
                    <button type="submit">Log in</button>
                    
                    <div class="center">
                    <center>
                    <?php
                    // If there was an error, display it
                    if($error != '') {
                        echo '<p style="color:red;">' . $error . '</p>';
                    }
                    ?>
                    </center>                   
                </form>
            </div>
        </div>
    </section>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>
