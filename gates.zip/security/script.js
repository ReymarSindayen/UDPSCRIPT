document.addEventListener('DOMContentLoaded', function() {
    const toastContainer = document.getElementById('toast-container');
    const error = document.getElementById('error').value;

    if (error) {
        const toast = document.createElement('div');
        toast.classList.add('toast');
        toast.textContent = error;
        toastContainer.appendChild(toast);

        setTimeout(function() {
            toast.remove();
        }, 5000);
    }
});